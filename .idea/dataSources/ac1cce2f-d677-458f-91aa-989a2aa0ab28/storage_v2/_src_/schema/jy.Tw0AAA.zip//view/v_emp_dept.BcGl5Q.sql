create view v_emp_dept as
select `e`.`pname` AS `pname`,`e`.`sal` AS `sal`,`e`.`deptno` AS `deptno`,`d`.`dname` AS `dname`
from `jy`.`emp` `e`
       join `jy`.`dept` `d`
where (`e`.`deptno` = `d`.`deptno`);

